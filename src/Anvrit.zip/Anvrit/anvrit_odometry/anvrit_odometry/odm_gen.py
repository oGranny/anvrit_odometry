import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseStamped, TransformStamped
from std_msgs.msg import Int32MultiArray
from nav_msgs.msg import Odometry
from tf2_ros import TransformBroadcaster
from math import atan2, cos, sin
import tf_transformations


class OdometryGen(Node):

    def __init__(self):
        super().__init__('ticks_counter')

        # Publishers & Subscribers
        self.publisher_ = self.create_publisher(Odometry, '/odometry', 10)
        self.ticks_subscription = self.create_subscription(Int32MultiArray, '/wheel_ticks', self.ticks_callback, 10)
        self.rviz_click_subscription = self.create_subscription(PoseStamped, '/initial_2d', self.set_initial_2d, 10)

        self.tf_broadcaster = TransformBroadcaster(self)

        # Constants
        self.TICKS_PER_METER = 38420
        self.WHEEL_BASE = 0.85

        # Robot State Variables
        self.x = 0.0
        self.y = 0.0
        self.theta = 0.0
        self.last_time = self.get_clock().now()

        # Tick Tracking (Fix for velocity issue)
        self.prev_left_ticks = None
        self.prev_right_ticks = None

        self.get_logger().info("Odometry Node Initialized ")

    def set_initial_2d(self, rviz_click: PoseStamped):
        """ Set initial position from RViz click """
        self.x = rviz_click.pose.position.x
        self.y = rviz_click.pose.position.y
        _, _, self.theta = tf_transformations.euler_from_quaternion([
            rviz_click.pose.orientation.x,
            rviz_click.pose.orientation.y,
            rviz_click.pose.orientation.z,
            rviz_click.pose.orientation.w
        ])

        self.get_logger().info(f"Initial position set from RViz: x={self.x}, y={self.y}, theta={self.theta}")

    def ticks_callback(self, ticks_data: Int32MultiArray):
        """ Callback to compute odometry from wheel encoder ticks """
        if len(ticks_data.data) < 2:
            self.get_logger().warn("Received incomplete wheel tick data")
            return

        left_ticks = ticks_data.data[0]
        right_ticks = ticks_data.data[1]

        self.get_logger().info(f"Received wheel ticks: Left={left_ticks}, Right={right_ticks}")

        # If first tick reading, initialize previous tick counts and return
        if self.prev_left_ticks is None or self.prev_right_ticks is None:
            self.prev_left_ticks = left_ticks
            self.prev_right_ticks = right_ticks
            return

        # Compute incremental ticks since last update
        delta_left_ticks = left_ticks - self.prev_left_ticks
        delta_right_ticks = right_ticks - self.prev_right_ticks

        # Store current ticks as previous for the next iteration
        self.prev_left_ticks = left_ticks
        self.prev_right_ticks = right_ticks

        # Convert wheel tick differences to distance moved
        distance_left = delta_left_ticks / self.TICKS_PER_METER
        distance_right = delta_right_ticks / self.TICKS_PER_METER

        # Compute distance moved and change in angle
        delta_distance = (distance_right + distance_left) / 2.0
        delta_theta = (distance_left - distance_right) / self.WHEEL_BASE

        # Get time delta for velocity calculation
        current_time = self.get_clock().now()
        dt = (current_time - self.last_time).nanoseconds / 1e9  # Convert to seconds
        self.last_time = current_time

        if dt == 0:
            self.get_logger().warn("Time delta is zero, skipping velocity calculation")
            return

        # Compute new pose
        self.theta += 2*(delta_theta)
        self.x += delta_distance * cos(self.theta)
        self.y += delta_distance * sin(self.theta)

        # Compute velocities
        linear_velocity = delta_distance / dt
        angular_velocity = delta_theta / dt

        self.get_logger().info(f"Updated Pose: x={self.x:.4f}, y={self.y:.4f}, theta={self.theta:.4f} | Velocities: linear={linear_velocity:.4f}, angular={angular_velocity:.4f}")

        # Publish Odometry Message
        odom_msg = Odometry()
        odom_msg.header.stamp = current_time.to_msg()
        odom_msg.header.frame_id = "odom"
        odom_msg.child_frame_id = "base_link"
        odom_msg.pose.pose.position.x = self.x
        odom_msg.pose.pose.position.y = self.y

        # Convert theta to quaternion
        quat = tf_transformations.quaternion_from_euler(0, 0, self.theta)
        odom_msg.pose.pose.orientation.x = quat[0]
        odom_msg.pose.pose.orientation.y = quat[1]
        odom_msg.pose.pose.orientation.z = quat[2]
        odom_msg.pose.pose.orientation.w = quat[3]

        odom_msg.twist.twist.linear.x = linear_velocity
        odom_msg.twist.twist.angular.z = angular_velocity

        self.publisher_.publish(odom_msg)
        self.get_logger().info("Published odometry message")

        # Publish TF Transform
        t = TransformStamped()
        t.header.stamp = current_time.to_msg()
        t.header.frame_id = "odom"
        t.child_frame_id = "base_link"
        t.transform.translation.x = self.x/1000
        t.transform.translation.y = self.y/1000
        t.transform.translation.z = 0.0
        t.transform.rotation.x = quat[0]
        t.transform.rotation.y = quat[1]
        t.transform.rotation.z = quat[2]
        t.transform.rotation.w = quat[3]

        self.tf_broadcaster.sendTransform(t)
        self.get_logger().info("Published TF Transform")


def main(args=None):
    rclpy.init(args=args)
    odom_generator = OdometryGen()
    rclpy.spin(odom_generator)
    odom_generator.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
