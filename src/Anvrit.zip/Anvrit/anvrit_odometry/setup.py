from setuptools import find_packages, setup
import os
from glob import glob

package_name = 'anvrit_odometry'

setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name] if os.path.exists('resource/' + package_name) else []),
        ('share/' + package_name, ['package.xml']),
        ('share/' + package_name + '/launch', glob('launch/*.py')),  # Ensure launch files are included
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='mohit',
    maintainer_email='mohit@todo.todo',
    description='TODO: Package description',
    license='TODO: License declaration',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'ticks_publisher=anvrit_odometry.ticks_pub:main',
            'rpm_gen=anvrit_odometry.rpm_gen:main',
            'teleop=anvrit_odometry.teleop:main',
            'pid=anvrit_odometry.controller:main',
            'odometry_gen=anvrit_odometry.odometry_gen:main',
            'odm_gen1=anvrit_odometry.odm_gen:main'
        ],
    },
)
